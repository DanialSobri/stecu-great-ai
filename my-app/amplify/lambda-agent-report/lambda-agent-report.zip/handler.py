import json
import boto3
import re
import os

def handler(event, context):
    """
    AWS Lambda handler for processing accident incident summaries
    """
    try:
        # Parse the request body
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
        
        transcription = body.get('transcription', '')
        
        if not transcription:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS'
                },
                'body': json.dumps({'error': 'Transcription is required'})
            }
        
        # Initialize AWS Bedrock client
        AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID", "AKIA3ODSYGTRA7YEA7HL")
        AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY", "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")
        
        client = boto3.client(
            "bedrock-runtime",
            region_name="us-east-1",
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        )
        
        model_id = "openai.gpt-oss-120b-1:0"
        
        # Create the prompt
        prompt = f"""
        you are the assistant to create the accident incident summary, keep it short and precise and informative. 
        Use the following format for your response:
        <incident_overview>...</incident_overview>
        <key_observation>...</key_observation>

        This is the incident details:
        Description of the Van Accident Scene
        - The van's front end is heavily damaged — the bumper torn off, headlights shattered, and the hood crumpled inward.
        - The windshield is cracked in multiple places, with glass fragments scattered across the asphalt.
        - Airbags inside the van are deployed, and the steering wheel is bent slightly from the force of the impact.
        - There are fluids leaking beneath the van, likely coolant or oil, creating a dark puddle on the road.
        - The van is immobilized across the lane, blocking traffic, with skid marks visible leading up to the point of collision.

        This is the transcription of what happened of victims:
        {transcription}
        """
        
        # Prepare the request body for Bedrock
        body_request = {
            "messages": [
                {"role": "assistant", "content": prompt},
            ],
            "temperature": 0,
            "top_p": 0.5,
        }
        
        # Call Bedrock API
        response = client.invoke_model(
            modelId=model_id,
            body=json.dumps(body_request),
        )
        
        response_body = json.loads(response["body"].read())
        print("Bedrock response:")
        print(response_body)
        
        # Extract the summary from the response
        summary = None
        if "output" in response_body and "message" in response_body["output"]:
            for msg in response_body["output"]["message"]["content"]:
                if "text" in msg:
                    summary = msg["text"]
                    break
        if not summary and "choices" in response_body:
            summary = response_body['choices'][0]['message']['content']
        
        # Remove <reasoning>...</reasoning> if present
        summary = re.sub(r"<reasoning>.*?</reasoning>", "", summary or "", flags=re.DOTALL).strip()
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps({'summary': summary})
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps({'error': str(e)})
        }
